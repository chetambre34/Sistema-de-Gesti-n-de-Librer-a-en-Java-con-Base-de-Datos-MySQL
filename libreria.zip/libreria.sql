CREATE DATABASE libreria;
USE libreria;

-- Tabla autores
CREATE TABLE autor (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100)
);

-- Tabla editoriales
CREATE TABLE editorial (
    id_editorial INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100)
);

-- Tabla libros
CREATE TABLE libro (
    id_libro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    fecha_publicacion DATE,
    id_autor INT,
    id_editorial INT,
    FOREIGN KEY (id_autor) REFERENCES autor(id_autor),
    FOREIGN KEY (id_editorial) REFERENCES editorial(id_editorial)
);

-- INSERTS (todo conectado)
INSERT INTO autor (nombre) VALUES 
('Isabel Allende'),
('Jorge Luis Borges'),
('Ernest Hemingway'),
('Paulo Coelho'),
('Miguel de Cervantes');

INSERT INTO editorial (nombre) VALUES 
('Alfaguara'),
('Seix Barral'),
('Sudamericana'),
('Planeta México'),
('HarperCollins');

INSERT INTO libro (titulo, fecha_publicacion, id_autor, id_editorial) VALUES
('La casa de los espiritus', '1982-01-01', 4, 4),
('Ficciones', '1944-01-01', 5, 1),
('El Aleph', '1949-01-01', 5, 2),
('El viejo y el mar', '1952-01-01', 6, 5),
('El alquimista', '1988-01-01', 7, 3),
('Don Quijote de la Mancha', '1605-01-01', 8, 1),
('Rayuela', '1963-06-28', 3, 2),
('Cien años de soledad', '1967-05-30', 1, 1);

SELECT * FROM libro;