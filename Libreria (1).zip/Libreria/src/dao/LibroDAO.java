/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.Conexion;
import modelo.Libro;
import java.sql.*;
import java.util.ArrayList;

public class LibroDAO {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public void insertar(Libro l){
        String sql = "INSERT INTO libro(titulo, fecha_publicacion, id_autor, id_editorial) VALUES(?,?,?,?)";

        try {
            con = cn.conectar();
            ps = con.prepareStatement(sql);
            ps.setString(1, l.titulo);
            ps.setString(2, l.fecha_publicacion);
            ps.setInt(3, l.id_autor);
            ps.setInt(4, l.id_editorial);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void eliminar(int id){
        String sql = "DELETE FROM libro WHERE id_libro=?";

        try {
            con = cn.conectar();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}