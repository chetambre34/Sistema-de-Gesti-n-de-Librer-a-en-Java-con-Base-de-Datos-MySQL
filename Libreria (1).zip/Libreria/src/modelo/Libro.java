/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Libro {
    public int id_libro;
    public String titulo;
    public String fecha_publicacion;
    public int id_autor;
    public int id_editorial;
}
