/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    Connection con;

    public Connection conectar(){
        try {
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/libreria",
                "root",
                "Tamayo26@"
            );
              System.out.println("Conexion exitosa"); 
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return con;
    }
}
